package org.example.enums;

public enum FigureType {
    CIRCULO,
    CUBO,
    HEXAGONO,
    LOSANGULO,
    PARALELOGRAMA,
    QUADRADO,
    RETANGULO,
    TRAPEZIO,
    TRIANGULO,
    PIRAMIDE,
    PRISMA,
    CILINDRO,
    ESFERA
}
