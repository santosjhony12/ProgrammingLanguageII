package org.example;

import org.example.enums.FigureType;

public class Main {
    public static void main(String[] args) {
        //System.out.println(Factory.create(FigureType.RETANGULO, 2.0,4.0).calcularArea());
    }
}