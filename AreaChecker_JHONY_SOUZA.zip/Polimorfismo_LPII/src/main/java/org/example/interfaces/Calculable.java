package org.example.interfaces;

public interface Calculable {
    Double calcularArea();
}
