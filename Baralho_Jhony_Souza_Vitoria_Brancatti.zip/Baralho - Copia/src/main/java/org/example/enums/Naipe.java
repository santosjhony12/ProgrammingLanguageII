package org.example.enums;

public enum Naipe {
    COPAS, PAUS, VALETE, OURO, CORINGA;

}
